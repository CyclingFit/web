import React from 'react';
import { useTranslation } from 'react-i18next';
import { Bike, Github, Twitter } from 'lucide-react';

const Footer = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-start">
            <div className="flex items-center space-x-2">
              <Bike className="h-8 w-8 text-indigo-600" />
              <span className="text-xl font-bold text-gray-900">CyclingFit</span>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              {t('footer.description')}
            </p>
            <p className="mt-2 text-sm font-medium text-indigo-600">
              {t('footer.credits')}
            </p>
          </div>
          <div className="flex flex-col space-y-4">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">
              {t('footer.links')}
            </h3>
            <div className="flex flex-col space-y-2">
              <a href="#" className="text-base text-gray-500 hover:text-indigo-600">
                {t('footer.about')}
              </a>
              <a href="#" className="text-base text-gray-500 hover:text-indigo-600">
                {t('footer.contact')}
              </a>
              <a href="#" className="text-base text-gray-500 hover:text-indigo-600">
                {t('footer.privacy')}
              </a>
            </div>
          </div>
          <div className="flex flex-col space-y-4">
            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider">
              {t('footer.social')}
            </h3>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-indigo-600">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-indigo-600">
                <Github className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-200 pt-8">
          <p className="text-base text-gray-400 text-center">
            &copy; {new Date().getFullYear()} CyclingFit. {t('footer.rights')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;