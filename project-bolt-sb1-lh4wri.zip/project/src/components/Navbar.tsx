import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Bike, Menu, X } from 'lucide-react';

const Navbar = () => {
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = React.useState(false);

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Bike className="h-8 w-8 text-indigo-600" />
              <span className="text-xl font-bold text-gray-900">CyclingFit</span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-indigo-600">
              {t('home')}
            </Link>
            <Link to="/analysis" className="text-gray-700 hover:text-indigo-600">
              {t('analysis')}
            </Link>
            <div className="flex space-x-2">
              <button
                onClick={() => changeLanguage('es')}
                className="px-3 py-1 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100"
              >
                ES
              </button>
              <button
                onClick={() => changeLanguage('en')}
                className="px-3 py-1 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100"
              >
                EN
              </button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-indigo-600 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link
              to="/"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-50"
            >
              {t('home')}
            </Link>
            <Link
              to="/analysis"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-gray-50"
            >
              {t('analysis')}
            </Link>
            <div className="flex space-x-2 px-3 py-2">
              <button
                onClick={() => changeLanguage('es')}
                className="px-3 py-1 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100"
              >
                ES
              </button>
              <button
                onClick={() => changeLanguage('en')}
                className="px-3 py-1 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100"
              >
                EN
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;