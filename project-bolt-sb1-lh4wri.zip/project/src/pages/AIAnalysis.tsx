import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import Webcam from 'react-webcam';
import { Camera, Upload, MessageSquare } from 'lucide-react';
import { analyzeImage, getChatResponse } from '../utils/ai';

const AIAnalysis = () => {
  const { t } = useTranslation();
  const webcamRef = useRef<Webcam>(null);
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string }>>([]);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const captureImage = React.useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      setImage(imageSrc);
      if (imageSrc) handleImageAnalysis(imageSrc);
    }
  }, [webcamRef]);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImage(base64String);
        handleImageAnalysis(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageAnalysis = async (imageData: string) => {
    setLoading(true);
    try {
      const result = await analyzeImage(imageData);
      setAnalysis(result);
    } catch (error) {
      console.error('Error analyzing image:', error);
      setAnalysis(t('analysis.error'));
    }
    setLoading(false);
  };

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newMessage = { role: 'user', content: message };
    setChatHistory([...chatHistory, newMessage]);
    setMessage('');
    setLoading(true);

    try {
      const response = await getChatResponse(message, chatHistory);
      setChatHistory(prev => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      console.error('Error getting chat response:', error);
      setChatHistory(prev => [...prev, { role: 'assistant', content: t('chat.error') }]);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Image Analysis Section */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">{t('analysis.title')}</h2>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            {!image && (
              <Webcam
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                className="w-full rounded-lg"
              />
            )}
            {image && (
              <img src={image} alt="Captured" className="w-full rounded-lg" />
            )}
            
            <div className="mt-4 flex space-x-4">
              <button
                onClick={captureImage}
                className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                <Camera className="h-5 w-5 mr-2" />
                {t('analysis.capture')}
              </button>
              
              <label className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 cursor-pointer">
                <Upload className="h-5 w-5 mr-2" />
                {t('analysis.upload')}
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>

              {image && (
                <button
                  onClick={() => setImage(null)}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
                >
                  {t('analysis.clear')}
                </button>
              )}
            </div>
          </div>

          {loading && (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
            </div>
          )}
          
          {analysis && (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold mb-4">{t('analysis.results')}</h3>
              <p className="text-gray-700 whitespace-pre-line">{analysis}</p>
            </div>
          )}
        </div>

        {/* Chat Section */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">{t('chat.title')}</h2>
          
          <div className="bg-white rounded-lg shadow-md h-[600px] flex flex-col">
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {chatHistory.map((msg, index) => (
                <div
                  key={index}
                  className={`flex ${
                    msg.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      msg.role === 'user'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleChatSubmit} className="p-4 border-t">
              <div className="flex space-x-4">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={t('chat.placeholder')}
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  disabled={loading}
                />
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                >
                  <MessageSquare className="h-5 w-5" />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAnalysis;