import { GoogleGenerativeAI } from '@google/generative-ai';

// Initialize Gemini Pro
const genAI = new GoogleGenerativeAI(process.env.VITE_GEMINI_API_KEY || '');

const CYCLING_CONTEXT = `
You are CyclingFit AI, an advanced AI assistant specialized in cycling biomechanics and training.
Created by Iker Oyarbide Basterretxea, you combine deep knowledge of:
- Cycling biomechanics and posture analysis
- Training techniques and performance optimization
- Sports psychology and motivation
- General wellness and injury prevention

When analyzing images:
1. Focus on key biomechanical aspects
2. Provide specific, actionable recommendations
3. Consider the cyclist's comfort and efficiency
4. Explain the reasoning behind each suggestion

Maintain a supportive, professional tone while being approachable and encouraging.
`;

export const analyzeImage = async (imageData: string): Promise<string> => {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro-vision' });
    
    const prompt = `
    Analyze this cycling posture image and provide detailed feedback on:
    1. Saddle position and height
    2. Handlebar position
    3. Back angle and alignment
    4. Knee position and angle
    5. Overall aerodynamics
    
    Format the response in Spanish with clear sections and actionable recommendations.
    `;

    const result = await model.generateContent([prompt, { inlineData: { data: imageData, mimeType: 'image/jpeg' } }]);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw error;
  }
};

export const getChatResponse = async (
  message: string,
  history: Array<{ role: string; content: string }>
): Promise<string> => {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const chat = model.startChat({
      history: [
        { role: 'assistant', parts: CYCLING_CONTEXT },
        ...history.map(msg => ({
          role: msg.role,
          parts: msg.content,
        })),
      ],
    });

    const result = await chat.sendMessage(message);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Error getting chat response:', error);
    throw error;
  }
};