import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    fallbackLng: 'es',
    resources: {
      es: {
        translation: {
          home: 'Inicio',
          analysis: 'Análisis',
          landing: {
            hero: {
              title1: 'Optimiza tu',
              title2: 'postura en bicicleta',
              description: 'Utiliza inteligencia artificial para analizar y mejorar tu posición sobre la bicicleta. Obtén recomendaciones personalizadas en tiempo real.',
              cta: 'Comenzar análisis',
            },
            features: {
              title: 'Tecnología avanzada para ciclistas',
              subtitle: 'Herramientas potentes para mejorar tu rendimiento',
              feature1: {
                title: 'Análisis de postura en tiempo real',
                description: 'Captura tu posición y recibe análisis instantáneo con IA.',
              },
              feature2: {
                title: 'Asistente virtual CyclingFit',
                description: 'Chat inteligente para resolver todas tus dudas sobre biomecánica.',
              },
              feature3: {
                title: 'Recomendaciones profesionales',
                description: 'Consejos personalizados basados en estándares profesionales.',
              },
            },
          },
          analysis: {
            title: 'Análisis de postura',
            capture: 'Capturar',
            upload: 'Subir imagen',
            clear: 'Borrar',
            results: 'Resultados del análisis',
            error: 'Error al analizar la imagen. Por favor, intenta de nuevo.',
          },
          chat: {
            title: 'CyclingFit Assistant',
            placeholder: 'Escribe tu pregunta aquí...',
            error: 'Error al procesar tu mensaje. Por favor, intenta de nuevo.',
          },
          footer: {
            description: 'Mejorando el rendimiento de ciclistas con inteligencia artificial',
            links: 'Enlaces',
            about: 'Sobre nosotros',
            contact: 'Contacto',
            privacy: 'Privacidad',
            social: 'Redes sociales',
            rights: 'Todos los derechos reservados.',
            credits: 'Creado por Iker Oyarbide Basterretxea',
          },
        },
      },
      en: {
        translation: {
          home: 'Home',
          analysis: 'Analysis',
          landing: {
            hero: {
              title1: 'Optimize your',
              title2: 'cycling posture',
              description: 'Use artificial intelligence to analyze and improve your position on the bike. Get personalized recommendations in real-time.',
              cta: 'Start analysis',
            },
            features: {
              title: 'Advanced technology for cyclists',
              subtitle: 'Powerful tools to improve your performance',
              feature1: {
                title: 'Real-time posture analysis',
                description: 'Capture your position and receive instant AI analysis.',
              },
              feature2: {
                title: 'CyclingFit Virtual Assistant',
                description: 'Smart chat to solve all your biomechanics questions.',
              },
              feature3: {
                title: 'Professional recommendations',
                description: 'Personalized advice based on professional standards.',
              },
            },
          },
          analysis: {
            title: 'Posture Analysis',
            capture: 'Capture',
            upload: 'Upload image',
            clear: 'Clear',
            results: 'Analysis Results',
            error: 'Error analyzing image. Please try again.',
          },
          chat: {
            title: 'CyclingFit Assistant',
            placeholder: 'Type your question here...',
            error: 'Error processing your message. Please try again.',
          },
          footer: {
            description: 'Improving cyclist performance with artificial intelligence',
            links: 'Links',
            about: 'About us',
            contact: 'Contact',
            privacy: 'Privacy',
            social: 'Social Media',
            rights: 'All rights reserved.',
            credits: 'Created by Iker Oyarbide Basterretxea',
          },
        },
      },
    },
  });

export default i18n;